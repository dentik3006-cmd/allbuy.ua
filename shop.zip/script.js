const products = [
    { name: "Футболка Червона", price: "499₴", image: "images/tshirt1.jpg" },
    { name: "Футболка Синя", price: "399₴", image: "images/tshirt2.jpg" },
    { name: "Навушники Pro", price: "1200₴", image: "images/headphones1.jpg" },
    { name: "Навушники Basic", price: "799₴", image: "images/headphones2.jpg" }
];

const grid = document.getElementById("products-grid");

products.forEach(product => {
    const card = document.createElement("div");
    card.classList.add("product-card");
    card.innerHTML = `
        <img src="${product.image}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>${product.price}</p>
    `;
    grid.appendChild(card);
});